public class cls_userBorrowBook {

    static enum BorrowOrReturnBooks{ BORROW,RETURN};

    public static void userBorrowBook(){

        System.out.println(" Enter user name & book name want to borrow it : " );

       String bookAndUserName = cls_commonFunctionBetweenBorrowAndReturnBook.EnterNameUserAndBook();

       if(bookAndUserName==null){
           return;
       }

       String [] parts = bookAndUserName.split("/");

       String userName=parts[0];
       String bookName = parts[1];

       int idBook=cls_commonFunctionBetweenBorrowAndReturnBook.GetIdBookByNameBook(bookName);

        cls_commonFunctionBetweenBorrowAndReturnBook.ChangeUsersNumberOfBookReturnAndBorrow(userName,bookName,cls_global.Users,cls_global.bookInfo,BorrowOrReturnBooks.BORROW);
        cls_commonFunctionBetweenBorrowAndReturnBook.ChangeNumberQuantityBooksReturnAndBorrow(userName,bookName,cls_global.Users,cls_global.bookInfo,BorrowOrReturnBooks.BORROW);


        System.out.println(" Done Borrow Successfully :) ");

    }


}
