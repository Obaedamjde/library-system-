import java.util.List;

public class cls_userReturnBook {

    public static void userReturnBook(){

        System.out.println(" Enter user name & book name want to return it : ");

        String bookAndUserName = cls_commonFunctionBetweenBorrowAndReturnBook.EnterNameUserAndBook();

        if(bookAndUserName==null){
            return;
        }

        String [] parts = bookAndUserName.split("/");

        String userName=parts[0];
        String bookName = parts[1];

        if(! isUserBorrowBook(userName,bookName,cls_global.bookInfo)){
            System.out.println("Sorry ,this user doesn't borrowed any book " );
            return;
        }
        cls_commonFunctionBetweenBorrowAndReturnBook.ChangeUsersNumberOfBookReturnAndBorrow(userName,bookName,cls_global.Users,cls_global.bookInfo, cls_userBorrowBook.BorrowOrReturnBooks.RETURN);
        cls_commonFunctionBetweenBorrowAndReturnBook.ChangeNumberQuantityBooksReturnAndBorrow(userName,bookName,cls_global.Users,cls_global.bookInfo, cls_userBorrowBook.BorrowOrReturnBooks.RETURN);

        System.out.println(" Done Return Book Successfully :) ");
    }
    private static boolean isUserBorrowBook(String userName, String bookName , List<cls_bookInfo>Books){

        for (var book : Books){
            if(book.NAME.equalsIgnoreCase(bookName)){
                for(var user :book.nameUserBorrow){
                    if(user.equalsIgnoreCase(userName)){
                        return true;
                    }
                }
            }
        }
        return false;
    }
}
