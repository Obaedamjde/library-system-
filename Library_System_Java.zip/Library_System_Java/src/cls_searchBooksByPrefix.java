import java.util.ArrayList;
import java.util.List;

public class cls_searchBooksByPrefix {

    static List<String>namesBooksPrefix=new ArrayList<>();
    static String prefix=null;

    public static void searchBooksByPrefix(){

        namesBooksPrefix.clear();
        System.out.println("Enter book name prefix : " );
        prefix=cls_inputValidation.readString("").trim().toLowerCase();

        for (var temp : cls_global.bookInfo) {
            if (temp.NAME.length() >= prefix.length() && temp.NAME.substring(0, prefix.length()).equalsIgnoreCase(prefix)) {
                namesBooksPrefix.add(temp.NAME);
            }
        }

        test();
    }

    private static void test(){
        if (namesBooksPrefix.isEmpty()) {
            System.out.println("No books found with the given prefix.");
            return;
        } else {
            System.out.println("**Number of Books found with the prefix '" + prefix + "' was " + namesBooksPrefix.size()+ " Books:");
            int counter=1;
            for (String bookName : namesBooksPrefix) {
                System.out.println( counter + "- "+bookName);
                counter++;
            }
        }
        System.out.println();
    }
}
