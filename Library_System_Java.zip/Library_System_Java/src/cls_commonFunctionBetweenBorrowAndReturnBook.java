import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class cls_commonFunctionBetweenBorrowAndReturnBook {

    public static String EnterNameUserAndBook() {
        String userName = cls_inputValidation.readString("");
        userName = userName.toLowerCase();

        String bookName = cls_inputValidation.readString("");
        bookName = bookName.toLowerCase();

        if (!(cls_inputValidation.isNameUserExist(userName, cls_global.Users))) {
            System.out.println("** Sorry ,this user not found , enter user first ");
            return null;
        }

        if (!(cls_inputValidation.isNameBookExist(bookName, cls_global.bookInfo))) {
            System.out.println("** Sorry ,this book not found , enter book first ");
            return null;
        }


        if (cls_global.Users.isEmpty()) {
            System.out.println("There is no user yet , enter user first .");
            return null;

        }
        if (cls_global.bookInfo.isEmpty()) {
            System.out.println("There is no Book yet , enter Book first .");
            return null;
        }
        String both = userName + "/" + bookName;
        return both;
    }


    public static int GetIdBookByNameBook(String nameBook) {
        int idBook = 0;
        for (var book : cls_global.bookInfo) {
            if (book.NAME.equalsIgnoreCase(nameBook)) {
                idBook = book.ID;
            }
        }
        return idBook;
    }


    public static void validationOfUserAndBookIsExist(String nameUser, String bookName) {

        if (!(cls_inputValidation.isNameBookExist(bookName, cls_global.bookInfo))) {
            System.out.println(" Sorry ,this book not found , enter book first ");
            return;
        }

        if (!(cls_inputValidation.isNameUserExist(nameUser, cls_global.Users))) {
            System.out.println(" Sorry ,this user not found , enter user first ");
            return;
        }
    }


    public static boolean isTotalBooksGreaterThanZero(String nameBook, List<cls_bookInfo> Books) {
        for (var book : Books) {
            if (book.NAME.equalsIgnoreCase(nameBook)) {
                if (book.total_quantity > 0)
                    return true;
            }
        }
        return false;

    }


    public static boolean isTotalBorrowedBooksGreaterThanZero(String nameBook, List<cls_bookInfo> Books) {
        for (var book : Books) {
            if (book.NAME.equalsIgnoreCase(nameBook)) {
                if (book.total_borrowed > 0)
                    return true;
            }
        }
        return false;

    }


    public static void ChangeNumberQuantityBooksReturnAndBorrow(String nameUser, String nameBook, List<cls_UserBook> USERS, List<cls_bookInfo> Books, cls_userBorrowBook.BorrowOrReturnBooks borrowOrReturnBooks) {

        switch (borrowOrReturnBooks) {
            case BORROW -> {

                for (var book : Books) {
                    if (book.NAME.equalsIgnoreCase(nameBook)) {
                        if (!(isTotalBooksGreaterThanZero(nameBook, Books))) {
                            System.out.println("Sorry the total books must be Greater than Zero ");
                            return;
                        }
                        book.total_borrowed++;
                        book.total_quantity--;
                        book.nameUserBorrow.add(nameUser);
                        return;
                    }
                }
                break;
            }
            case RETURN -> {
                for (var book : Books) {
                    if (book.NAME.equalsIgnoreCase(nameBook)) {

                        if (!(isTotalBorrowedBooksGreaterThanZero(nameBook, Books))) {
                            System.out.println("** Sorry total Borrowed Books must be GreaterThanZero");
                            return;
                        }

                        book.total_quantity++;
                        book.total_borrowed--;
                        List<String> nameUserBorrowAfterReturn = new ArrayList<>();

                        for (var user : book.nameUserBorrow) {
                            if (!(user.equalsIgnoreCase(nameUser))) {
                                nameUserBorrowAfterReturn.add(user);
                            }
                        }
                        book.nameUserBorrow = nameUserBorrowAfterReturn;
                        return;
                    }
                }
                break;
            }

        }
    }


    public static void ChangeUsersNumberOfBookReturnAndBorrow(String nameUser, String nameBook, List<cls_UserBook> USERS, List<cls_bookInfo> Books, cls_userBorrowBook.BorrowOrReturnBooks borrowOrReturnBooks) {

        Integer idBook = GetIdBookByNameBook(nameBook);
        switch (borrowOrReturnBooks) {

            case BORROW -> {
                for (var user : USERS) {

                    if (user.nameUser.equalsIgnoreCase(nameUser)) {
                        if (user.nameBorrowedBooksWithId == null) {
                            user.nameBorrowedBooksWithId = new ArrayList<>();
                        }
                        user.nameBorrowedBooksWithId.add(new AbstractMap.SimpleEntry<>(nameBook, idBook));
                    }
                }

            }
            case RETURN -> {
                for (var user : USERS) {
                    if (user.nameUser.equalsIgnoreCase(nameUser)) {
                        List<Map.Entry<String, Integer>> newIdAndBookAfterReturn = new ArrayList<>();
                        for (var book : user.nameBorrowedBooksWithId) {
                            if (!(book.getValue().equals(idBook))) {
                                newIdAndBookAfterReturn.add(new AbstractMap.SimpleImmutableEntry<>(book.getKey(), book.getValue()));
                            }
                        }
                        user.nameBorrowedBooksWithId = newIdAndBookAfterReturn;
                        return;
                    }
                }

                break;
            }

        }
    }

}