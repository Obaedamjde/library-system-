import java.util.List;

public class cls_addBook {

    // static Scanner scanner=new Scanner(System.in);

    public static boolean isIdBookExit(int id, List<cls_bookInfo> bookInfo) {
        for (var temp : bookInfo) {
            if (temp.ID == id) {
                return true;
            }
        }
        return false;
    }


    public static void addBook() {

        System.out.println("Enter book info : id & name & total quantity : ");

        cls_bookInfo Book = new cls_bookInfo();

        Book.ID = cls_inputValidation.readIntNumber(" Invalid Number , Enter ID again :\n ");
        if (isIdBookExit(Book.ID, cls_global.bookInfo)) {
            System.out.println(" **Note :Book ID already exists ,Please enter other ID Book : ");
            return;
        }

        Book.NAME = cls_inputValidation.readString(" Enter Book Name : ");
        Book.total_quantity = cls_inputValidation.readIntNumber("Invalid Number ,  Enter total quantity again :\n ");

        Book.NAME=Book.NAME.toLowerCase();
        if (!(Book.total_quantity > 0)) {
            System.out.println("Quantity of this book must be greater than zero ");
            return;
        }


        cls_global.bookInfo.add(Book);
        System.out.println(" Added Book Successfully :) ");
        System.out.println();
}

//    private static void testPrint(){
//        for(var temp : cls_global.bookInfo){
//            System.out.println(temp.ID + " " + temp.NAME + " " + temp.total_quantity);
//        }
//    }
}
