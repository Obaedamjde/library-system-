import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class cls_printLibraryByName {

    public static void printLibraryByName(){
        List<cls_bookInfo> libraryAfterSortedByName = new ArrayList<>();

        libraryAfterSortedByName=cls_global.bookInfo;
        if(libraryAfterSortedByName.isEmpty()){
            System.out.println("** Sorry there is no books until now , Enter Books please .");
            return;
        }
        libraryAfterSortedByName.sort(Comparator.comparing(book -> book.NAME));
        cls_global.counter=1;
        for(var book : libraryAfterSortedByName){
            System.out.println(cls_global.counter +") Book ID: " + book.ID + " , Book Name: " + book.NAME + " ,total_quantity: " +book.total_quantity +" ,total_borrowed: " +book.total_borrowed);
            cls_global.counter++;
        }
        System.out.println();
    }
}
