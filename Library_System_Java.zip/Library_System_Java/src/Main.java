
public class Main {
    public static void main(String[] args) {
        cls_librarySystem.start();
    }
}
