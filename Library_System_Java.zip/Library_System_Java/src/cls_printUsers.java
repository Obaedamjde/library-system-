public class cls_printUsers {

    public static void printUsers(){

        if(cls_global.Users.isEmpty()){
            System.out.println("** Sorry there is no user until now , Enter users please .");
            return;
        }
        int counter =1;
        for(var user : cls_global.Users){
            System.out.print(counter+"- USER [" +user.nameUser + "], ID [" + user.idUser+ "] Borrowed "+/*user.nameBorrowedBooksWithId.size() +*/"books : ");
            if(user.nameBorrowedBooksWithId!=null) {
                for (var book : user.nameBorrowedBooksWithId) {
                    System.out.print(book.getKey() + "[" + book.getValue() + "]    ");
                }
            }
            System.out.println();
            counter++;
        }
    }
}
