import java.util.ArrayList;
import java.util.List;

public class cls_global {
    static int counter=0;
    static final int MAX_NUMBER_CHOICE=11;
    static List<cls_bookInfo>bookInfo=new ArrayList<>();
    static List<cls_UserBook>Users=new ArrayList<>();


}
