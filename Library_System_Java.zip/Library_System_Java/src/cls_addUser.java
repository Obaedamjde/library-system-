public class cls_addUser {

    public static void addUser(){
        System.out.println("Enter user name & national Id : ");
        cls_UserBook USER=new cls_UserBook();

        USER.nameUser=cls_inputValidation.readString("").trim().toLowerCase();
        USER.idUser=cls_inputValidation.readIntNumber("Enter valid ID again please  :");

        if(isIdUserExit(USER.idUser)){
            System.out.println("** Sorry The id user is exist , enter new user again ");
            return;
        }
        if(cls_inputValidation.isNameUserExist(USER.nameUser,cls_global.Users)){
            System.out.println("** Sorry The name user is exist , enter new user again ");
            return;
        }

        cls_global.Users.add(USER);

        System.out.println("** Added User Successfully :)");
    }
    private static boolean isIdUserExit(int id){
        for(var user : cls_global.Users){
            if(user.idUser ==id){
                return true;
            }
        }
        return false;
    }
}
