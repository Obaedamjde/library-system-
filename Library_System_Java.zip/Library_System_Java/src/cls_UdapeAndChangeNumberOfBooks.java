public class cls_UdapeAndChangeNumberOfBooks {

    public static void ChangeAndUpdate() {


        cls_bookInfo Book = new cls_bookInfo();

        System.out.println("Enter ID and Book name in order please : ");
        Book.ID = cls_inputValidation.readIntNumber(" Invalid Number , Enter ID again :\n ");

        for (var temp : cls_global.bookInfo) {
            while (!(temp.ID == Book.ID)) {
                System.out.println("sorry this ID book doesnt exists , enter right ID please :");
                Book.ID = cls_inputValidation.readIntNumber(" Invalid Number , Enter ID again :\n ");
            }
            Book.NAME = cls_inputValidation.readString("");

            if (!(temp.NAME.trim().equalsIgnoreCase(Book.NAME))) {

                System.out.println(" **Note :Book ID already exists with a different name: " + temp.NAME);
                System.out.println(" **Note :The book name will not be updated.");
                Book.NAME = temp.NAME;
                System.out.println();

            }

                    System.out.println("The book is exist ,Do you want to update value  of total_quantity for book " + " ' "+Book.NAME +" ' "+ " ? ");
                    System.out.println();
                    System.out.println("Enter Y (YES) to update the total quantity or N (NO) " + " ' "+Book.NAME +" ' ");

                    String status = cls_inputValidation.readString("Enter Y / N  please");
                    System.out.println("Enter the number you want to change : ");
                    int changeNumber = cls_inputValidation.readIntNumber("");


                    if (status.toLowerCase().charAt(0)== 'y') {
                        temp.total_quantity =changeNumber;
                        System.out.println("Quantity updated successfully for book: " + temp.NAME +", total quantity :" +temp.total_quantity);
                        System.out.println();
                    } else {
                        temp.total_quantity = Book.total_quantity;
                    }
                    return;
                }
        }
}
