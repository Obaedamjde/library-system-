import java.util.List;

public class cls_printWhoBorrowedBookByName {


    public static void printWhoBorrowedBookByName(){

        System.out.println("Enter Book Name Please : ");
        String nameBook=cls_inputValidation.readString("").trim().toLowerCase();

        if( !(cls_inputValidation.isNameBookExist(nameBook,cls_global.bookInfo))){
            System.out.println("** Sorry this book is not exist , enter valid book .");
            return;
        }

        if(cls_global.bookInfo.isEmpty()){
            System.out.println("** Sorry the library is empty , Enter books first .");
        }
        findWhoBorrowedBookByName(nameBook,cls_global.bookInfo);

    }


    private static void findWhoBorrowedBookByName(String name, List<cls_bookInfo>Books){
        for(var temp: Books){
            if(temp.NAME.equalsIgnoreCase(name)){
                int counter=1;
                for(var user :temp.nameUserBorrow){
                    System.out.println(counter +"- " +user);
                    counter++;
                }
            }
        }
    }
}
