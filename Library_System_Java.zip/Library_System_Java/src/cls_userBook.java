import java.util.List;
import java.util.Map;

class cls_UserBook{
    int idUser;
    String nameUser;
    String emailUser;
    String addressUser;
    List<Map.Entry<String,Integer> > nameBorrowedBooksWithId;


    public cls_UserBook(){}
    private cls_UserBook(int idUser, String nameUser, String emailUser, String addressUser, List<Map.Entry<String, Integer>> nameBorrowedBooksWithId) {
        this.idUser = idUser;
        this.nameUser = nameUser;
        this.emailUser = emailUser;
        this.addressUser = addressUser;
        this.nameBorrowedBooksWithId = nameBorrowedBooksWithId;
    }
}