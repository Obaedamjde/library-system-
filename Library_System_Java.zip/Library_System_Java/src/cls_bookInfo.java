import java.util.ArrayList;
import java.util.List;

public class cls_bookInfo {

     int ID;
     String NAME;
     int total_quantity ;
     int total_borrowed ;
     List<String>nameUserBorrow=new ArrayList<>();

     public cls_bookInfo(){
          ID=-1;
          NAME=null;
          total_borrowed = total_quantity = 0;
     }

     private cls_bookInfo(int ID, String NAME, int total_quantity, int total_borrowed, List<String> nameUserBorrow) {
          this.ID = ID;
          this.NAME = NAME;
          this.total_quantity = total_quantity;
          this.total_borrowed = total_borrowed;
          this.nameUserBorrow = nameUserBorrow;
     }
     public static cls_bookInfo find(int id){

          for(var temp :cls_global.bookInfo){
               if(temp.ID==id){
                    return  new cls_bookInfo(temp.ID,temp.NAME,temp.total_quantity,temp.total_borrowed,temp.nameUserBorrow);
               }
          }
          return null;
     }
}
