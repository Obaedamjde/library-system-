import java.util.List;
import java.util.Scanner;

public class cls_inputValidation {

    static Scanner scanner=new Scanner(System.in);

    public static int readIntNumber(String Error_massage){
        int number=0;
        boolean check=false;
        while(!check) {
            try {
                String numberStr = scanner.nextLine();
                number = Integer.parseInt(numberStr);
                check=true;
            } catch (NumberFormatException e) {
                System.out.println(Error_massage);
            }
        }
        return number;
    }


    public static boolean isNumberBetween(int from, int to, int number){
        if(from>to){
            int temp=from;
            from=to;
            to=temp;
        }
        return (from<=number && to>=number);
    }


    public static int readIntNumberBetween(int from,int to ,String Error_massage){
        int number=readIntNumber(" Invalid Number , Enter again :\n ");
        while ( !(isNumberBetween(from,to,number))){
            System.out.println(Error_massage);
            number=readIntNumber(" Invalid Number , Enter again :\n ");

        }
        return number;
    }

    public static String readString(String massage){
        String name =scanner.nextLine();
        return name;
    }

    public static boolean isNameBookExist(String name, List<cls_bookInfo> bookInfo){

        boolean isExist=false;
        for(int z=0;z<bookInfo.size();z++){
            if(bookInfo.get(z).NAME.equalsIgnoreCase(name)){
                return true;
            }
        }
        return false;
    }
    public static boolean isNameUserExist(String name, List<cls_UserBook>USERS){

        boolean isExist=false;
        for(int z=0;z<USERS.size();z++){
            if(USERS.get(z).nameUser.equalsIgnoreCase(name)){
                isExist=true;
            }
        }
        return isExist;
    }


}
