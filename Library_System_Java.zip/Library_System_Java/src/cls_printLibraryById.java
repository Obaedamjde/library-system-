import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class cls_printLibraryById {

    public static void printLibraryById(){
        List<cls_bookInfo> libraryAfterSortedById = new ArrayList<>();

        libraryAfterSortedById=cls_global.bookInfo;
        if(libraryAfterSortedById.isEmpty()){
            System.out.println("** Sorry there is no books until now , Enter Books please .");
            return;
        }
        libraryAfterSortedById.sort(Comparator.comparingInt(book -> book.ID));
        cls_global.counter=1;
        for(var book : libraryAfterSortedById){
            System.out.println(cls_global.counter +") Book ID: " + book.ID + " , Book Name: " + book.NAME + " ,total_quantity: " +book.total_quantity +" ,total_borrowed: " +book.total_borrowed);
            cls_global.counter++;
        }
        System.out.println();
    }
}
