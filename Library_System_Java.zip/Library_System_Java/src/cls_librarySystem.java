public class cls_librarySystem {
     static enum LibraryMenu{
         Add_book ,
         Change_number_of_books,
         Search_books_by_prefix,
         Print_who_borrowed_book_by_name,
         Print_library_by_id,
         Print_library_by_name,
         Add_user,
         User_borrow_book,
         User_return_book,
         Print_users,
         EXIT_PROGRAM
     }

     public static void displayMenu(){
         String menu = """
Library menu:

1) Add book
2) Change and Update number of book
3) Search books by prefix
4) Print who borrowed book by name
5) Print library by ID
6) Print library by name
7) Add user
8) User borrow book
9) User return book
10) Print users
11) Exit

Enter your menu choice [1-11]:
""";
         System.out.println(menu);
     }


    public static void start(){

         while (true){


             displayMenu();
             int inputChoice= cls_inputValidation.readIntNumberBetween(1,cls_global.MAX_NUMBER_CHOICE,"input is invalid, number is not in the range , please enter again \n  ");
             LibraryMenu libraryMenu= cls_librarySystem.LibraryMenu.values()[inputChoice-1];


             switch (libraryMenu){
                 case Add_book -> {
                     cls_addBook.addBook();
                     //cls_addBook.testPrint();
                     break;
                 }
                 case Change_number_of_books -> {
                     cls_UdapeAndChangeNumberOfBooks.ChangeAndUpdate();
                     break;
                 }
                 case Search_books_by_prefix -> {
                     cls_searchBooksByPrefix.searchBooksByPrefix();
                     break;
                 }
                 case Print_who_borrowed_book_by_name -> {
                     cls_printWhoBorrowedBookByName.printWhoBorrowedBookByName();
                     break;
                 }
                 case Print_library_by_id -> {
                     cls_printLibraryById.printLibraryById();
                     break;
                 }
                 case Print_library_by_name -> {
                     cls_printLibraryByName.printLibraryByName();
                     break;
                 }
                 case Add_user -> {
                     cls_addUser.addUser();
                     break;
                 }
                 case User_borrow_book -> {
                     cls_userBorrowBook.userBorrowBook();
                 }
                 case User_return_book -> {
                     cls_userReturnBook.userReturnBook();
                 }
                 case Print_users -> {
                     cls_printUsers.printUsers();
                 }
                 case EXIT_PROGRAM -> {
                     System.out.println("Thanks for using library system , hope enjoy with it ");
                     System.out.println("Done By  '( Obaeda_Majde ) ' Good Bye >3 ");
                     break;
                 }
             }
         }
    }

}
